package school.sptech;

public class Teste {

    public static void main(String[] args) {
        Pet[] pets = {
                new Pet(1001, "Bob", 150.42, 3),
                new Pet(1002, "Max", 100.21, 1),
                new Pet(1003, "Rex", 560.32, 4),
                new Pet(1004, "Zoe", 299.90, 5),
                new Pet(1005, "Tom", 175.67, 7),
                new Pet(1006, "Mia", 470.80, 2),
        };

//        GestaoPets.exibePets(pets);
    }
}
