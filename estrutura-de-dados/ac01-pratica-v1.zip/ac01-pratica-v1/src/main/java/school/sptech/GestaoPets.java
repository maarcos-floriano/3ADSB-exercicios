package school.sptech;

public class GestaoPets {
    public static boolean alterarValorVisita(Pet[] pets, Integer id, Double valorNovo) {
        return true;
    }

    public static Double somaValorVisitas(Pet[] pets) {
        return null;
    }

    public static void trocaPets(Pet[] pets, Integer idPet01, Integer idPet02) {

    }

    //Corrija o erro na ordenação abaixo:
    public static void ordenarPorQtdVisitas(Pet[] pets) {
        for (int i = 0; i < pets.length - 1; i++) {
            int indiceMenor = i;
            for (int j = i + 1; j < pets.length; j++) {
                if (pets[j].getQtdVisitas() < pets[indiceMenor].getQtdVisitas()) {
                    indiceMenor = pets[j].getQtdVisitas();
                }
            }
            Pet aux = pets[i];
            pets[i] = pets[indiceMenor];
            pets[indiceMenor] = aux;
        }
    }

    //Corrija o erro na ordenação abaixo:
    public static void ordenarPorQtdVisitasDecrescente(Pet[] pets) {
        for (int i = 0; i < pets.length - 1; i++) {
            for (int j = i + 1; j < pets.length; j++) {
                if (pets[j].getQtdVisitas() < pets[i].getQtdVisitas()) {
                    Pet aux = pets[i];
                    pets[i] = pets[j];
                    pets[j] = aux;
                }
            }
        }
    }

    //Complete o código da ordenação abaixo dentro do "if"
    public static void ordenarPorNomePet(Pet[] pets) {
        for (int i = 0; i < pets.length - 1; i++) {
            for (int j = 1; j < pets.length - i; j++) {
                if (pets[j - 1].getNome().compareTo(pets[j].getNome()) > 0) {
                    //Necessário completar aqui
                }
            }
        }
    }

    //Exibe os itens do vetor
    //Já está pronto para usar no main se precisar testar
    public static void exibePets(Pet[] pets) {
        for (int i = 0; i < pets.length; i++) {
            System.out.println(pets[i]);
        }
    }
}
