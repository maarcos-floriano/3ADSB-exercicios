package school.sptech;

//Classe completa - não é necessário alterar!
public class Pet {
    private Integer id;
    private String nome;
    private Double valorVisita;
    private Integer qtdVisitas;

    public Pet(Integer id, String nome, Double valorVisita, Integer qtdVisitas) {
        this.id = id;
        this.nome = nome;
        this.valorVisita = valorVisita;
        this.qtdVisitas = qtdVisitas;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Double getValorVisita() {
        return valorVisita;
    }

    public void setValorVisita(Double valorVisita) {
        this.valorVisita = valorVisita;
    }

    public Integer getQtdVisitas() {
        return qtdVisitas;
    }

    public void setQtdVisitas(Integer qtdVisitas) {
        this.qtdVisitas = qtdVisitas;
    }

    @Override
    public String toString() {
        return """
        Id: %d     Nome: %s     Valor da Visita: %.2f     Quantidade Visitas: %d""".formatted(id, nome, valorVisita, qtdVisitas);
    }
}
