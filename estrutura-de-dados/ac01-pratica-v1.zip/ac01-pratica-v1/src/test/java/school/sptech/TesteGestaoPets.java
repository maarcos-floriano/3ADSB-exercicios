package school.sptech;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class TesteGestaoPets {
    private Pet[] pets;

    @BeforeEach
    void setUp() {
        pets = new Pet[]{
                new Pet(1001, "Bob", 150.42, 3),
                new Pet(1002, "Max", 100.21, 1),
                new Pet(1003, "Rex", 560.32, 4),
                new Pet(1004, "Zoe", 299.90, 5),
                new Pet(1005, "Tom", 175.67, 7),
                new Pet(1006, "Mia", 470.80, 2)
        };
    }

    @Test
    @DisplayName("01) Método alterarValorVisita - Altera Corretamente")
    void testAlterarValorVisita_Success() {
        boolean result = GestaoPets.alterarValorVisita(pets, 1003, 600.00);
        assertTrue(result);
        assertEquals(600.00, pets[2].getValorVisita());
    }

    @Test
    @DisplayName("02) Método alterarValorVisita - Quando id inválido")
    void testAlterarValorVisita_IdNotFound() {
        boolean result = GestaoPets.alterarValorVisita(pets, 9999, 600.00);
        assertFalse(result);
    }

    @Test
    @DisplayName("03) Método somaValorVisitas - Soma Corretamente")
    void testSomaValorVisitas_Success() {
        Double result = GestaoPets.somaValorVisitas(pets);
        assertEquals(1757.32, result);
    }

    @Test
    @DisplayName("04) Método somaValorVisitas - Com vetor vazio")
    void testSomaValorVisitas_EmptyArray() {
        Double result = GestaoPets.somaValorVisitas(new Pet[0]);
        assertEquals(0.0, result);
    }

    @Test
    @DisplayName("05) Método trocaPets - Troca Corretamente")
    void testTrocaPets_Success() {
        GestaoPets.trocaPets(pets, 1001, 1004);

        assertEquals(1004, pets[0].getId());
        assertEquals("Zoe", pets[0].getNome());
        assertEquals(299.90, pets[0].getValorVisita());
        assertEquals(5, pets[0].getQtdVisitas());

        assertEquals(1001, pets[3].getId());
        assertEquals("Bob", pets[3].getNome());
        assertEquals(150.42, pets[3].getValorVisita());
        assertEquals(3, pets[3].getQtdVisitas());
    }

    @Test
    @DisplayName("06) Método trocaPets - Com idPet01 e idPet02 iguais")
    void testTrocaPets_SameId() {
        GestaoPets.trocaPets(pets, 1001, 1001);
        assertEquals(1001, pets[0].getId());
        assertEquals("Bob", pets[0].getNome());
        assertEquals(150.42, pets[0].getValorVisita());
        assertEquals(3, pets[0].getQtdVisitas());
    }

    @Test
    @DisplayName("07) Método trocaPets - Com idPet01 inválido")
    void testTrocaPets_IdNotFound() {
        GestaoPets.trocaPets(pets, 9999, 1004);
        assertEquals(1001, pets[0].getId());
        assertEquals(1004, pets[3].getId());
    }

    @Test
    @DisplayName("08) Método ordenarPorQtdVisitas - Ordena Corretamente")
    void testOrdenarPorQtdVisitas_Success() {
        GestaoPets.ordenarPorQtdVisitas(pets);

        assertEquals(1002, pets[0].getId());
        assertEquals("Max", pets[0].getNome());
        assertEquals(100.21, pets[0].getValorVisita());
        assertEquals(1, pets[0].getQtdVisitas());

        assertEquals(1006, pets[1].getId());
        assertEquals("Mia", pets[1].getNome());
        assertEquals(470.80, pets[1].getValorVisita());
        assertEquals(2, pets[1].getQtdVisitas());

        assertEquals(1001, pets[2].getId());
        assertEquals("Bob", pets[2].getNome());
        assertEquals(150.42, pets[2].getValorVisita());
        assertEquals(3, pets[2].getQtdVisitas());

        assertEquals(1003, pets[3].getId());
        assertEquals("Rex", pets[3].getNome());
        assertEquals(560.32, pets[3].getValorVisita());
        assertEquals(4, pets[3].getQtdVisitas());

        assertEquals(1004, pets[4].getId());
        assertEquals("Zoe", pets[4].getNome());
        assertEquals(299.90, pets[4].getValorVisita());
        assertEquals(5, pets[4].getQtdVisitas());

        assertEquals(1005, pets[5].getId());
        assertEquals("Tom", pets[5].getNome());
        assertEquals(175.67, pets[5].getValorVisita());
        assertEquals(7, pets[5].getQtdVisitas());
    }

    @Test
    @DisplayName("09) Método ordenarPorQtdVisitasDecrescente - Ordena Corretamente")
    void testOrdenarPorQtdVisitasDecrescente_Success() {
        GestaoPets.ordenarPorQtdVisitasDecrescente(pets);

        assertEquals(1005, pets[0].getId());
        assertEquals("Tom", pets[0].getNome());
        assertEquals(175.67, pets[0].getValorVisita());
        assertEquals(7, pets[0].getQtdVisitas());

        assertEquals(1004, pets[1].getId());
        assertEquals("Zoe", pets[1].getNome());
        assertEquals(299.90, pets[1].getValorVisita());
        assertEquals(5, pets[1].getQtdVisitas());

        assertEquals(1003, pets[2].getId());
        assertEquals("Rex", pets[2].getNome());
        assertEquals(560.32, pets[2].getValorVisita());
        assertEquals(4, pets[2].getQtdVisitas());

        assertEquals(1001, pets[3].getId());
        assertEquals("Bob", pets[3].getNome());
        assertEquals(150.42, pets[3].getValorVisita());
        assertEquals(3, pets[3].getQtdVisitas());

        assertEquals(1006, pets[4].getId());
        assertEquals("Mia", pets[4].getNome());
        assertEquals(470.80, pets[4].getValorVisita());
        assertEquals(2, pets[4].getQtdVisitas());

        assertEquals(1002, pets[5].getId());
        assertEquals("Max", pets[5].getNome());
        assertEquals(100.21, pets[5].getValorVisita());
        assertEquals(1, pets[5].getQtdVisitas());
    }

    @Test
    @DisplayName("10) Método ordenarPorNomePet - Ordena Corretamente")
    void testOrdenarPorNomePet_Success() {
        GestaoPets.ordenarPorNomePet(pets);

        assertEquals(1001, pets[0].getId());
        assertEquals("Bob", pets[0].getNome());
        assertEquals(150.42, pets[0].getValorVisita());
        assertEquals(3, pets[0].getQtdVisitas());

        assertEquals(1002, pets[1].getId());
        assertEquals("Max", pets[1].getNome());
        assertEquals(100.21, pets[1].getValorVisita());
        assertEquals(1, pets[1].getQtdVisitas());

        assertEquals(1006, pets[2].getId());
        assertEquals("Mia", pets[2].getNome());
        assertEquals(470.80, pets[2].getValorVisita());
        assertEquals(2, pets[2].getQtdVisitas());

        assertEquals(1003, pets[3].getId());
        assertEquals("Rex", pets[3].getNome());
        assertEquals(560.32, pets[3].getValorVisita());
        assertEquals(4, pets[3].getQtdVisitas());

        assertEquals(1005, pets[4].getId());
        assertEquals("Tom", pets[4].getNome());
        assertEquals(175.67, pets[4].getValorVisita());
        assertEquals(7, pets[4].getQtdVisitas());

        assertEquals(1004, pets[5].getId());
        assertEquals("Zoe", pets[5].getNome());
        assertEquals(299.90, pets[5].getValorVisita());
        assertEquals(5, pets[5].getQtdVisitas());
    }
}
