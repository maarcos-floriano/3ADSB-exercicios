package school.sptech;

public class Jogador {
    private int id;
    private String nome;
    private int idade;
    private double altura;
    private double peso;
    private int gols;

    public Jogador(int id, String nome, int idade, double altura, double peso, int gols) {
        this.id = id;
        this.nome = nome;
        this.idade = idade;
        this.altura = altura;
        this.peso = peso;
        this.gols = gols;
    }

    // Getters
    public int getId() { return id; }
    public String getNome() { return nome; }
    public int getIdade() { return idade; }
    public double getAltura() { return altura; }
    public double getPeso() { return peso; }
    public int getGols() { return gols; }

    // ToString para exibição
    @Override
    public String toString() {
        return "ID: " + id + ", Nome: " + nome + ", Idade: " + idade + ", Altura: " + altura + "m, Peso: " + peso + "kg, Gols: " + gols;
    }
}
