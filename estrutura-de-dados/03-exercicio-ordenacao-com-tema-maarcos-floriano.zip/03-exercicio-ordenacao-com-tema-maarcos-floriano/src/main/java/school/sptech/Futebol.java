package school.sptech;

import java.util.Arrays;

public class Futebol {
    public static void main(String[] args) {
        Jogador[] jogadores = {
                new Jogador(1, "Neymar", 31, 1.75, 68.0, 20),
                new Jogador(2, "Cristiano Ronaldo", 39, 1.87, 83.0, 25),
                new Jogador(3, "Messi", 36, 1.70, 72.0, 28),
                new Jogador(4, "Mbappé", 25, 1.78, 73.0, 22),
                new Jogador(5, "Lewandowski", 35, 1.85, 81.0, 30),
                new Jogador(6, "Salah", 32, 1.75, 72.0, 18),
                new Jogador(7, "Kane", 30, 1.88, 86.0, 21),
                new Jogador(8, "Son", 31, 1.83, 77.0, 15)
        };

        System.out.println("Ordenando com Selection Sort (decrescente por gols):");
        Jogador[] jogadoresParaSelectionSort = Arrays.copyOf(jogadores, jogadores.length);
        selectionSortDecrescentePorGols(jogadoresParaSelectionSort);
        exibirJogadores(jogadoresParaSelectionSort);

        System.out.println("\nOrdenando com Bubble Sort (decrescente por gols):");
        Jogador[] jogadoresParaBubbleSort = Arrays.copyOf(jogadores, jogadores.length);
        bubbleSortDecrescentePorGols(jogadoresParaBubbleSort);
        exibirJogadores(jogadoresParaBubbleSort);

        System.out.println("\nOrdenando com Insertion Sort (decrescente por gols):");
        Jogador[] jogadoresParaInsertionSort = Arrays.copyOf(jogadores, jogadores.length);
        insertionSortDecrescentePorGols(jogadoresParaInsertionSort);
        exibirJogadores(jogadoresParaInsertionSort);
    }

    public static void selectionSortDecrescentePorGols(Jogador[] jogadores) {
        int n = jogadores.length;
        int comparacoes = 0;
        int trocas = 0;

        for (int i = 0; i < n - 1; i++) {
            int indiceMaior = i;
            for (int j = i + 1; j < n; j++) {
                comparacoes++;
                if (jogadores[j].getGols() > jogadores[indiceMaior].getGols()) {
                    indiceMaior = j;
                }
            }

            if (indiceMaior != i) {
                Jogador temp = jogadores[i];
                jogadores[i] = jogadores[indiceMaior];
                jogadores[indiceMaior] = temp;
                trocas++;
            }
        }

        System.out.println("Comparações: " + comparacoes);
        System.out.println("Trocas: " + trocas);
    }

    public static void bubbleSortDecrescentePorGols(Jogador[] jogadores) {
        int n = jogadores.length;
        int comparacoes = 0;
        int trocas = 0;

        boolean trocou;
        do {
            trocou = false;
            for (int i = 0; i < n - 1; i++) {
                comparacoes++;
                if (jogadores[i].getGols() < jogadores[i + 1].getGols()) {
                    // Troca os jogadores
                    Jogador temp = jogadores[i];
                    jogadores[i] = jogadores[i + 1];
                    jogadores[i + 1] = temp;
                    trocas++;
                    trocou = true;
                }
            }
            n--;
        } while (trocou);

        System.out.println("Comparações: " + comparacoes);
        System.out.println("Trocas: " + trocas);
    }

    public static void insertionSortDecrescentePorGols(Jogador[] jogadores) {
        int n = jogadores.length;
        int comparacoes = 0;
        int trocas = 0;

        for (int i = 1; i < n; i++) {
            Jogador chave = jogadores[i];
            int j = i - 1;

            // Move os jogadores de jogadores[0..i-1] que têm menos gols que chave
            // para uma posição à frente de sua posição atual
            while (j >= 0 && jogadores[j].getGols() < chave.getGols()) {
                jogadores[j + 1] = jogadores[j];
                j--;
                comparacoes++;
                trocas++;
            }
            jogadores[j + 1] = chave;

            // Conta a comparação quando o while termina
            if (j >= 0) comparacoes++;
        }

        System.out.println("Comparações: " + comparacoes);
        System.out.println("Trocas: " + trocas);
    }

    public static void exibirJogadores(Jogador[] jogadores) {
        System.out.println("Lista de Jogadores:");
        for (Jogador jogador : jogadores) {
            System.out.println(jogador);
        }
    }
}
