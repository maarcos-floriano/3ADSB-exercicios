package school.sptech;

public class ListaEstatica {
    private int[] vetor;
    private int nroElem;

    public ListaEstatica(int nroElem) {
        this.vetor = new int[nroElem];
        this.nroElem = 0;
    }

    public void adiciona(int elemento){
        if (nroElem >= vetor.length){
            System.out.println("Lista cheia");
        }

        vetor[nroElem] = elemento;
        nroElem++;
    }

    public void exibe(){
        for (int i = 0; i < nroElem; i++){
            System.out.println(vetor[i]);
        }
    }

    public int busca(int elemento){
        for (int i = 0; i < nroElem; i++){
            if (vetor[i] == elemento){
                return i;
            }
        }
        return -1;
    }

    public boolean removePeloIndice(int indice){
        if (indice < 0 || indice >= nroElem){
            return false;
        }
        for (int i = indice; i < nroElem - 1; i++){
            vetor[i] = vetor[i + 1];
        }
        nroElem--;
        return true;
    }

    public boolean removeElemento(int elemento){
        int indice = busca(elemento);
        return (indice == -1) ? false : removePeloIndice(indice);
    }
}
