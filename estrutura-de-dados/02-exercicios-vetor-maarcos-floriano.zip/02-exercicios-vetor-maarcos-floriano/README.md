Crie um projeto chamado exercicio-vetor.

Para cada exercício, crie uma classe (Exercicio1, Exercicio2, etc)

1.  Escreva um programa que leia 7 números e armazene-os em um vetor. Depois, o programa deve percorrer o vetor exibindo os números na ordem em que foram inseridos. E depois, deve percorrer o vetor de trás para frente, exibindo os números na ordem inversa em que foram inseridos (dica: utilize o for ao contrário).

2.  Escreva um programa que cria um vetor para armazenar 10 inteiros. O programa deve solicitar que o usuário digite 10 números, que devem ser armazenados nesse vetor.
    O programa deverá calcular a média dos números digitados e exibir a média.
    Depois, deverá exibir os números que estão no vetor que estão acima da média.

3.  Escreva um programa que cria um vetor para armazenar 10 Strings. O programa deve solicitar que o usuário digite 10 nomes, que devem ser armazenados nesse vetor.
    Depois, o programa deve pedir que se digite um nome qualquer. O programa deverá pesquisar se esse nome está no vetor.
    Se estiver, deve exibir a mensagem: “Nome encontrado no índice x”, sendo x o índice do nome no vetor, senão deve exibir uma mensagem de “Nome não encontrado”.

4.  Elaborar um programa que solicita que o usuário digite 10 valores inteiros e armazene esses valores em um vetor. Depois o programa deve solicitar que o usuário digite um número qualquer e o programa deverá exibir quantas vezes esse número ocorre no vetor.

Exemplo:  considere os números 3  7  9  3  7  1  3  3  5  8
o número 7 ocorre 2 vezes
o número 3 ocorre 4 vezes
o número 2 não ocorre nenhuma vez. 