public class Main{

    public static void main(String[] args){

        int[] array = {12, 11, 13, 5, 6, 7};

        System.out.println("MergeSort");

        System.out.println("Array original:");
        for (int i = 0; i < array.length; i++) {
            System.out.print(array[i] + " ");
        }

        MergeSort.mergeSort(array, 0, array.length - 1);
        System.out.println("\nArray ordenado:");

        for (int i = 0; i < array.length; i++) {
            System.out.print(array[i] + " ");
        }

        System.out.println("\n\nQuickSort");

        int[] array2 = {12, 11, 13, 5, 6, 7};

        System.out.println("Array original:");
        for (int i = 0; i < array2.length; i++) {
            System.out.print(array2[i] + " ");
        }

        QuickSort.quickSort(array2, 0, array2.length - 1);
        System.out.println("\nArray ordenado:");
        for (int i = 0; i < array2.length; i++) {
            System.out.print(array2[i] + " ");
        }

    }

}