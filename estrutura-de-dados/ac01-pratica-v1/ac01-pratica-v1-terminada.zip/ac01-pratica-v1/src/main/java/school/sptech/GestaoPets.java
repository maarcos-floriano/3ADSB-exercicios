package school.sptech;

public class GestaoPets {
    public static boolean alterarValorVisita(Pet[] pets, Integer id, Double valorNovo) {
        for (int i = 0; i < pets.length; i++) {
            if (pets[i].getId().equals(id)) {
                pets[i].setValorVisita(valorNovo);
                return true;
            }
        }
        return false;
    }

    public static Double somaValorVisitas(Pet[] pets) {
        double soma = 0.0;
        for (Pet pet : pets) {
            soma += pet.getValorVisita();
        }
        return soma;
    }

    public static void trocaPets(Pet[] pets, Integer idPet01, Integer idPet02) {
        int indexPet01 = -1;
        int indexPet02 = -1;
        for (int i = 0; i < pets.length; i++) {
            if (pets[i].getId().equals(idPet01)) {
                indexPet01 = i;
            }
            if (pets[i].getId().equals(idPet02)) {
                indexPet02 = i;
            }
        }
        if (indexPet01 != -1 && indexPet02 != -1) {
            Pet temp = pets[indexPet01];
            pets[indexPet01] = pets[indexPet02];
            pets[indexPet02] = temp;
        }
    }

    public static void ordenarPorQtdVisitas(Pet[] pets) {
        for (int i = 0; i < pets.length - 1; i++) {
            int indiceMenor = i;
            for (int j = i + 1; j < pets.length; j++) {
                if (pets[j].getQtdVisitas() < pets[indiceMenor].getQtdVisitas()) {
                    indiceMenor = j;
                }
            }
            if (indiceMenor != i) {
                Pet aux = pets[i];
                pets[i] = pets[indiceMenor];
                pets[indiceMenor] = aux;
            }
        }
    }

    public static void ordenarPorQtdVisitasDecrescente(Pet[] pets) {
        for (int i = 0; i < pets.length - 1; i++) {
            for (int j = i + 1; j < pets.length; j++) {
                if (pets[j].getQtdVisitas() > pets[i].getQtdVisitas()) {
                    Pet aux = pets[i];
                    pets[i] = pets[j];
                    pets[j] = aux;
                }
            }
        }
    }

    public static void ordenarPorNomePet(Pet[] pets) {
        for (int i = 0; i < pets.length - 1; i++) {
            for (int j = 1; j < pets.length - i; j++) {
                if (pets[j - 1].getNome().compareTo(pets[j].getNome()) > 0) {
                    Pet aux = pets[j - 1];
                    pets[j - 1] = pets[j];
                    pets[j] = aux;
                }
            }
        }
    }

    public static void exibePets(Pet[] pets) {
        for (int i = 0; i < pets.length; i++) {
            System.out.println(pets[i]);
        }
    }
}