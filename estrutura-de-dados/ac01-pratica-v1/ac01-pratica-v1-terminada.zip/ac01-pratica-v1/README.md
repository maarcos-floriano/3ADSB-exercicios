# Avaliação Continuada 01 - Prática 📎

## 📌 Orientações Gerais:
1. Verifique se **não** há **erros de compilação** no projeto antes de enviar.
2. Respeite os nomes de atributos e métodos definidos no exercício.
3. Tome cuidado com os argumentos especificados no exercício. Não adicione argumentos não solicitados e mantenha a ordem definida no enunciado.
4. O projeto possui testes automatizados para ajuda-los a acompanhar a resolucão, para rodar os testes, clique com botão direito no nome do projeto, e em "Run All Tests".

## 🚨 Orientações para a avaliação:
- Não é necessário utilizar Pesquisa Binária
- Não é necessário criar métodos novos
- Já deixamos a assinatura dos métodos pronta, ou seja, basta preencher o corpo dos métodos 🙂
- Usar a classe Teste (método main) é opcional, mas pode te ajudar a entender possíveis erros

## 🐈 Gestão de Pets

Você recebeu a classe `GestaoPets` que contém métodos para gerenciar um array de objetos `Pet`. Sua tarefa é completar os métodos da classe conforme descrito abaixo. 
Caso ache necessário, teste cada método utilizando a classe `GestaoPets` no seu código principal (`main`).

### Métodos a serem completados na classe `GestaoPets`:

1. **alterarValorVisita(Pet[] pets, Integer id, Double valorNovo):**
    - Este método deve alterar o valor da visita de um `Pet` com o `id` fornecido.
    - Se o `id` for encontrado, o método deve atualizar o valor e retornar `true`. Caso contrário, deve retornar `false`.

2. **somaValorVisitas(Pet[] pets):**
    - Este método deve calcular e retornar a soma dos valores de todas as visitas dos pets no vetor.

3. **trocaPets(Pet[] pets, Integer idPet01, Integer idPet02):**
    - Este método deve trocar a posição dos pets no vetor baseando-se nos IDs fornecidos (`idPet01` e `idPet02`).

4. **ordenarPorQtdVisitas(Pet[] pets):**
    - Corrija o algoritmo de ordenação para que ordene corretamente os pets pelo número de visitas em ordem crescente.

5. **ordenarPorQtdVisitasDecrescente(Pet[] pets):**
    - O método está fazendo a ordenação crescente, **corrija** para que a ordenação dos pets seja feita pelo número de visitas em ordem **decrescente**.

6. **ordenarPorNomePet(Pet[] pets):**
    - Complete a lógica deste método para ordenar o vetor de pets em ordem alfabética crescente pelo nome do pet.
    - Necessário completar apenas dentro do `if`, foi adicionado um comentário indicando onde deve ser completado.  

### Dica:
- Para testar os métodos, você pode utilizar o método `exibePets(Pet[] pets)` já fornecido, que exibe os detalhes dos pets no console.

Boa prova!
