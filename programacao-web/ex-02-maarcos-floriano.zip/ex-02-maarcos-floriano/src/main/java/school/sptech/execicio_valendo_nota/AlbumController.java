package school.sptech.execicio_valendo_nota;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/albuns")
public class AlbumController {

    @Autowired
    private AlbumRepository repository;

    @GetMapping
    public ResponseEntity<List<Album>> listarAlbuns(){

        List<Album> albuns = this.repository.findAll();

        if (albuns.isEmpty()){

            return ResponseEntity.status(204).body(albuns);

        }

        return ResponseEntity.status(200).body(albuns);

    }

//    @PostMapping
//    public ResponseEntity<Album> criarAlbum(
//            @RequestBody Album albumNovo
//    ){
//
//        int id = this.repository
//
//    }

    @GetMapping("/{id}")
    public ResponseEntity<Optional<Album>> buscarPorId(
            @PathVariable Integer id
    ){

        Optional<Album> albumEncontrado = this.repository.findById(id);

        if (albumEncontrado.isPresent()) return ResponseEntity.status(200).body(albumEncontrado);

        return ResponseEntity.status(404).body(albumEncontrado);

    }

    @PutMapping("/{id}")
    public ResponseEntity<Album> atualizarAlbum(
            @PathVariable int id,
            @RequestBody Album album
    ){

        Optional<Album> albumParaAtualizar = this.repository.findById(id);

        if (albumParaAtualizar.isPresent()){

            album.setId(id);
            return ResponseEntity.status(200).body(this.repository.save(album));

        }

        return ResponseEntity.status(404).body(album);

    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletarAlbum(
            @PathVariable int id
    ){

        Optional<Album> albumParaDeletar = this.repository.findById(id);

        if (albumParaDeletar.isPresent()) {

            this.repository.delete(albumParaDeletar.get());
            return ResponseEntity.noContent().build();

        } else {

            return ResponseEntity.notFound().build();

        }

    }

    @GetMapping("/artistas")
    public ResponseEntity<List<Album>> buscarAlbunsPorArtista(
            @RequestParam String nome
    ){

        List<Album> albunsFiltrados = this.repository.findAlbumByArtistaContainingIgnoreCase(nome);

        if (albunsFiltrados.isEmpty()){

            return ResponseEntity.noContent().build();

        }

        return ResponseEntity.ok().body(albunsFiltrados);

    }

    @GetMapping("/mais-vendido")
    public ResponseEntity<Album> buscarAlbumMaisVendido(){

        List<Album> albunsOrdenados = this.repository.findAlbumsByOrderByTotalVendas();

        if (albunsOrdenados.isEmpty()){

            return ResponseEntity.notFound().build();

        }

        Album maisVendido = albunsOrdenados.get( albunsOrdenados.size()-1 );

        return ResponseEntity.ok().body(maisVendido);

    }

    @GetMapping("/menos-vendido")
    public ResponseEntity<Album> buscarAlbumMenosVendido(){

        List<Album> albunsOrdenados = this.repository.findAlbumsByOrderByTotalVendas();

        if (albunsOrdenados.isEmpty()){

            return ResponseEntity.notFound().build();

        }

        Album maisVendido = albunsOrdenados.get( 0 );

        return ResponseEntity.status(200).body(maisVendido);

    }

    @GetMapping("/periodo")
    public ResponseEntity<List<Album>> buscarPorPeriodo(
            @RequestParam LocalDate inicio,
            @RequestParam LocalDate fim
            ){

        if (inicio.isAfter(fim)){

            return ResponseEntity.status(400).body(null);

        }

        List<Album> albuns = this.repository.findAlbumsByDataLancamentoBetween(inicio, fim);

        if (albuns.isEmpty()){

            return ResponseEntity.status(204).build();

        }

        return ResponseEntity.status(200).body(albuns);

    }

}
