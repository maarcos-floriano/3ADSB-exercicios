package school.sptech.execicio_valendo_nota;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class Album {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String nome;

    private String artista;

    private LocalDate dataLancamento;

    private Integer quantidadeMusicas;

    private Double totalVendas;

    public Album(Double totalVendas, Integer quantidadeMusicas, LocalDate dataLancamento, String artista, String nome) {
        this.totalVendas = totalVendas;
        this.quantidadeMusicas = quantidadeMusicas;
        this.dataLancamento = dataLancamento;
        this.artista = artista;
        this.nome = nome;
    }
}
