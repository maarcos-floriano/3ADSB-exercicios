package school.sptech.execicio_valendo_nota;

import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;

public interface AlbumRepository extends JpaRepository<Album, Integer> {

    List<Album> findAlbumByArtistaContainingIgnoreCase(String nome);

    List<Album> findAlbumsByOrderByTotalVendas();

    List<Album> findAlbumsByDataLancamentoBetween(LocalDate inicio, LocalDate fim);

}
